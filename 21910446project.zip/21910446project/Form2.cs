﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _21910446project
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void adddata_Click(object sender, EventArgs e)
        {
            DataGridViewRow row = (DataGridViewRow)dgv.Rows[0].Clone();
            row.Cells[0].Value = tid.Text;
            row.Cells[1].Value = txNM;
            row.Cells[2].Value = txDT;
            row.Cells[3].Value = txDU;
            row.Cells[4].Value = pictureBox1.Image;
            dgv.Rows.Add(row);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Image files (*.bmp,*.jpg)|*.bmp;*.jpg";
            dialog.Title = "Please select an image file to encrypt.";

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image=new Bitmap(dialog.FileName);
            }
        }

        private void bindingNavigatorDeleteItem_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow item in this.dgv.SelectedRows)
            {
                dgv.Rows.RemoveAt(item.Index);
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            dgv.Update();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            using (Form3 form3 = new Form3())
            {
                form3.ShowDialog();
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            adddata.Enabled = true;
            de.Enabled = true;
        }
    }
}
