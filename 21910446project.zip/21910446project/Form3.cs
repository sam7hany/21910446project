﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _21910446project
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            clb.Items.Add(txd.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            for (int i = clb.Items.Count - 1; i >= 0; i--)
            {
                // clb is the name of the CheckedListBox control
                if (clb.GetItemChecked(i))
                {
                    clb.Items.Remove(clb.Items[i]);
                }
            }
        }

        private void Form3_Load(object sender, EventArgs e)
        {

            label1.Text = string.Format("You're have {0} tasks", clb.Items.Count.ToString());
            label2.Text = string.Format("You're completed {0} tasks ", chkListCount);
            int ntc = clb.Items.Count - clb.CheckedItems.Count;
            label3.Text = string.Format("You're not completed {0} tasks ", ntc);
            
        }

        private void clb_SelectedIndexChanged(object sender, EventArgs e)
        {
            
              
            
        }
        int chkListCount;
        private void clb_ItemCheck(object sender, ItemCheckEventArgs e)
        {
  if (e.NewValue == CheckState.Checked)
                {
                    chkListCount++;
                }
                else if (e.NewValue == CheckState.Unchecked)
                {
                    chkListCount--;
                }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            label1.Text = string.Format("You're have {0} tasks", clb.Items.Count.ToString());
            label2.Text = string.Format("You're completed {0} tasks ", chkListCount);
            int ntc = clb.Items.Count - chkListCount;
            label3.Text = string.Format("You're not completed {0} tasks ", ntc);
        }
    }
}
